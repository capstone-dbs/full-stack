from functools import lru_cache
import json
from pathlib import Path

import joblib
import numpy as np
import tensorflow as tf
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from tensorflow import keras
from tensorflow.keras import layers


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_ROOT / "models" / "stunting_model.keras"
SCALER_PATH = PROJECT_ROOT / "models" / "scaler.pkl"
MODEL_CONFIG_PATH = PROJECT_ROOT / "configs" / "model_config.json"

FEATURE_NAMES = ["Gender_Enc", "Age_Month", "Weight", "Height", "BMI"]
DEFAULT_PREDICTION_THRESHOLD = 0.5


class ResidualBlock(layers.Layer):
    def __init__(self, units: int, dropout_rate: float = 0.3, **kwargs):
        super().__init__(**kwargs)
        self.units = units
        self.dropout_rate = dropout_rate
        self.dense1 = layers.Dense(units, use_bias=False)
        self.bn1 = layers.BatchNormalization()
        self.drop1 = layers.Dropout(dropout_rate)
        self.dense2 = layers.Dense(units, use_bias=False)
        self.bn2 = layers.BatchNormalization()
        self.proj = None

    def build(self, input_shape):
        if input_shape[-1] != self.units:
            self.proj = layers.Dense(self.units, use_bias=False)
        super().build(input_shape)

    def call(self, x, training: bool = False):
        shortcut = x if self.proj is None else self.proj(x)
        out = tf.nn.relu(self.bn1(self.dense1(x), training=training))
        out = self.drop1(out, training=training)
        out = self.bn2(self.dense2(out), training=training)
        return tf.nn.relu(out + shortcut)

    def get_config(self):
        config = super().get_config()
        config.update({"units": self.units, "dropout_rate": self.dropout_rate})
        return config


class FocalLoss(keras.losses.Loss):
    def __init__(
        self,
        alpha: float = 0.75,
        gamma: float = 2.0,
        name: str = "focal_loss",
        **kwargs,
    ):
        super().__init__(name=name, **kwargs)
        self.alpha = alpha
        self.gamma = gamma

    def call(self, y_true, y_pred):
        y_true = tf.cast(y_true, tf.float32)
        y_pred = tf.clip_by_value(y_pred, 1e-7, 1.0 - 1e-7)
        bce = (
            -y_true * tf.math.log(y_pred)
            - (1 - y_true) * tf.math.log(1 - y_pred)
        )
        p_t = y_true * y_pred + (1 - y_true) * (1 - y_pred)
        alpha_t = y_true * self.alpha + (1 - y_true) * (1 - self.alpha)
        return tf.reduce_mean(alpha_t * tf.pow(1.0 - p_t, self.gamma) * bce)

    def get_config(self):
        config = super().get_config()
        config.update({"alpha": self.alpha, "gamma": self.gamma})
        return config


class PredictionRequest(BaseModel):
    gender: str
    age_months: int = Field(..., ge=0, le=60)
    weight_kg: float = Field(..., ge=1.0, le=30.0)
    height_cm: float = Field(..., ge=30.0, le=130.0)


class PredictionResponse(BaseModel):
    prediction_label: str
    probability: float
    threshold: float
    input_data: dict
    calculated_bmi: float


def encode_gender(gender: str) -> int:
    normalized = gender.strip().lower()
    if normalized in {"male", "laki-laki", "laki laki"}:
        return 1
    if normalized in {"female", "perempuan"}:
        return 0
    raise HTTPException(
        status_code=422,
        detail="gender hanya boleh male/female atau laki-laki/perempuan",
    )


def calculate_bmi(weight_kg: float, height_cm: float) -> float:
    return weight_kg / ((height_cm / 100) ** 2)


def load_model_config() -> dict:
    if not MODEL_CONFIG_PATH.exists():
        return {
            "feature_names": FEATURE_NAMES,
            "prediction_threshold": DEFAULT_PREDICTION_THRESHOLD,
            "threshold_strategy": "default 0.5",
        }

    with MODEL_CONFIG_PATH.open(encoding="utf-8") as f:
        config = json.load(f)

    configured_features = config.get("feature_names", FEATURE_NAMES)
    if configured_features != FEATURE_NAMES:
        raise RuntimeError(
            "Feature order mismatch between API and model config: "
            f"{configured_features} != {FEATURE_NAMES}"
        )
    return config


@lru_cache(maxsize=1)
def load_artifacts():
    if not MODEL_PATH.exists():
        raise RuntimeError(f"Model file not found: {MODEL_PATH}")
    if not SCALER_PATH.exists():
        raise RuntimeError(f"Scaler file not found: {SCALER_PATH}")

    model = keras.models.load_model(
        MODEL_PATH,
        custom_objects={"ResidualBlock": ResidualBlock, "FocalLoss": FocalLoss},
        compile=False,
    )
    scaler = joblib.load(SCALER_PATH)
    config = load_model_config()
    threshold = float(
        config.get("prediction_threshold", DEFAULT_PREDICTION_THRESHOLD)
    )
    return model, scaler, threshold


app = FastAPI(
    title="Stunting Detection API",
    description="REST API untuk prediksi stunting menggunakan input sederhana dan BMI otomatis.",
    version="1.0.0",
)


@app.get("/")
def health_check():
    config = load_model_config()
    return {
        "status": "ok",
        "model_path": str(MODEL_PATH),
        "model_features": FEATURE_NAMES,
        "threshold": float(
            config.get("prediction_threshold", DEFAULT_PREDICTION_THRESHOLD)
        ),
    }


@app.post("/predict", response_model=PredictionResponse)
def predict(payload: PredictionRequest):
    gender_enc = encode_gender(payload.gender)
    calculated_bmi = calculate_bmi(payload.weight_kg, payload.height_cm)

    feature_vector = np.array(
        [[
            gender_enc,
            payload.age_months,
            payload.weight_kg,
            payload.height_cm,
            calculated_bmi,
        ]],
        dtype=np.float32,
    )

    model, scaler, threshold = load_artifacts()
    features_scaled = scaler.transform(feature_vector)
    probability = float(model.predict(features_scaled, verbose=0)[0][0])
    prediction_label = "Resiko Stunting" if probability >= threshold else "Normal"

    return {
        "prediction_label": prediction_label,
        "probability": round(probability, 4),
        "threshold": round(threshold, 4),
        "input_data": {
            "gender": payload.gender,
            "gender_encoded": gender_enc,
            "age_months": payload.age_months,
            "weight_kg": payload.weight_kg,
            "height_cm": payload.height_cm,
            "feature_order": FEATURE_NAMES,
        },
        "calculated_bmi": round(calculated_bmi, 2),
    }
