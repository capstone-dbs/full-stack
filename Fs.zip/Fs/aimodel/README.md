# Stunting Detection with Deep Learning

Project ini membangun model deep learning untuk mendeteksi risiko stunting balita dari input sederhana: jenis kelamin, usia, berat badan, dan tinggi badan. Project juga dilengkapi REST API berbasis FastAPI agar model siap digunakan sebagai artefak submission bootcamp/kampus.

## Tujuan Project

- Melatih model klasifikasi biner untuk prediksi `Stunting` atau `Normal`.
- Menjaga pipeline inference tetap sederhana untuk user.
- Menghindari data leakage dari fitur turunan status gizi.
- Menyediakan export model, scaler, API, dokumentasi, dan visualisasi evaluasi yang rapi.

## Struktur Folder

```text
stunting-detection/
├── app/
│   ├── __init__.py
│   └── app.py
├── data/
│   └── data_gizi_balita.csv
├── models/
│   ├── stunting_model.keras
│   ├── scaler.pkl
│   └── stunting_saved_model/
├── notebooks/
│   └── stunting_detection_training.ipynb
├── logs/
│   ├── tensorboard/
│   └── training_log.csv
├── visualizations/
│   ├── correlation_heatmap.png
│   ├── eda_visualisasi.png
│   ├── evaluation_results.png
│   ├── calibration_curve.png
│   ├── cross_validation_baseline.png
│   ├── feature_importance.png
│   ├── gradient_tape_history.png
│   ├── tensorboard_snapshot.png
│   └── training_history.png
├── configs/
│   ├── cross_validation_baseline.csv
│   ├── feature_importance.csv
│   ├── model_quality_report.json
│   ├── scaler_params.json
│   └── model_config.json
├── samples/
│   └── sample_request.json
├── README.md
├── requirements.txt
└── .gitignore
```

## Dataset

Dataset utama berada di `data/data_gizi_balita.csv` dengan 3.807 sampel balita. Target model adalah `severe_stunting`, yaitu klasifikasi biner untuk membedakan balita stunting dan normal.

Distribusi target:

```text
Normal   : 72.3%
Stunting : 27.7%
```

## Fitur Input Model

Urutan fitur training dan inference dibuat konsisten:

```text
Gender_Enc, Age_Month, Weight, Height, BMI
```

Input dari user/API:

- `gender`
- `age_months`
- `weight_kg`
- `height_cm`

BMI tidak diminta dari user. BMI dihitung otomatis agar input tetap sederhana dan konsisten:

```python
BMI = weight_kg / ((height_cm / 100) ** 2)
```

## Pencegahan Data Leakage

Fitur berikut tidak digunakan sebagai input model:

- `ZScore_WA`
- `ZScore_HA`
- `ZScore_WH`
- `Total_ZScore`
- `WFA_Enc`
- `WFH_Enc`
- `AgeGroup_Enc`

Alasannya, fitur z-score dan encoded status gizi sangat dekat dengan aturan/definisi label stunting. Jika fitur tersebut dipakai, model dapat terlihat sangat akurat tetapi evaluasinya tidak realistis karena label bocor ke input.

## Revisi Kualitas Model

Notebook training sekarang menambahkan guardrail agar performa model lebih kuat dan lebih mudah dipercaya:

- Normalisasi label `severe_stunting` sebelum training agar nilai seperti `0 ` tidak menjadi kelas tersembunyi.
- BMI dihitung ulang dari `Weight` dan `Height` agar rumus training sama dengan API inference.
- Baseline tabular `LogisticRegression` dan `RandomForest` sebagai pembanding model deep learning.
- Stratified 5-fold cross-validation untuk baseline agar stabilitas performa lebih terlihat.
- Threshold tuning dari validation set dengan strategi F1 terbaik sambil menjaga recall stunting minimal 90%.
- Brier score untuk mengecek kualitas probabilitas, bukan hanya akurasi.
- Permutation feature importance untuk menjelaskan fitur yang paling memengaruhi prediksi.
- Calibration curve untuk mengecek apakah skor probabilitas cukup masuk akal.
- Export `configs/model_config.json` berisi urutan fitur, threshold, strategi threshold, dan metrik referensi.

## Arsitektur Model

Model dibangun menggunakan TensorFlow Keras Functional API dengan komponen utama:

- Dense stem layer
- 3 custom `ResidualBlock`
- self-attention feature gate
- classification head dengan sigmoid output

Komponen custom yang digunakan:

- `ResidualBlock`: custom layer dengan skip connection untuk membantu aliran gradien.
- `FocalLoss`: custom loss untuk membantu class imbalance.
- `StuntingMonitorCallback`: custom callback untuk checkpoint, early stopping, log CSV, dan monitoring target akurasi.
- `tf.GradientTape`: custom fine-tuning loop dengan gradient clipping.

## TensorBoard Monitoring

Training log TensorBoard tersedia di:

```text
logs/tensorboard/
```

Jalankan TensorBoard:

```bash
tensorboard --logdir logs/tensorboard
```

Snapshot monitoring:

![TensorBoard Snapshot](visualizations/tensorboard_snapshot.png)

## Visualisasi

Training history:

![Training History](visualizations/training_history.png)

GradientTape fine-tuning:

![GradientTape History](visualizations/gradient_tape_history.png)

EDA:

![EDA Visualization](visualizations/eda_visualisasi.png)

Correlation heatmap:

![Correlation Heatmap](visualizations/correlation_heatmap.png)

Evaluasi model, confusion matrix, dan ROC curve:

![Evaluation Results](visualizations/evaluation_results.png)

Cross-validation baseline:

![Cross Validation Baseline](visualizations/cross_validation_baseline.png)

Permutation feature importance:

![Feature Importance](visualizations/feature_importance.png)

Calibration curve dan distribusi probabilitas:

![Calibration Curve](visualizations/calibration_curve.png)

## Hasil Evaluasi

Evaluasi pada test set:

```text
Accuracy : 95.28%
ROC-AUC  : 0.9909
Threshold: 0.50
```

Confusion matrix:

```text
[[398  16]
 [ 11 147]]
```

Classification report:

```text
              precision    recall  f1-score   support
Normal          0.9731    0.9614    0.9672       414
Stunting        0.9018    0.9304    0.9159       158

accuracy                            0.9528       572
macro avg       0.9375    0.9459    0.9415       572
weighted avg    0.9534    0.9528    0.9530       572
```

Baseline 5-fold cross-validation:

```text
LogisticRegression : F1 0.6932 | ROC-AUC 0.8861
RandomForest       : F1 0.6651 | ROC-AUC 0.8998
```

Feature importance model final berdasarkan penurunan F1 saat fitur diacak:

```text
Weight     : 0.5349
Age_Month  : 0.4989
Height     : 0.4810
BMI        : 0.3975
Gender_Enc : 0.1704
```

## Cara Menjalankan Training

Install dependency:

```bash
pip install -r requirements.txt
```

Buka notebook:

```text
notebooks/stunting_detection_training.ipynb
```

Jalankan semua cell untuk melatih ulang model, menyimpan scaler, export model, visualisasi, dan evaluasi.

Artefak training utama:

- `models/stunting_model.keras`
- `models/scaler.pkl`
- `models/stunting_saved_model/`
- `configs/scaler_params.json`
- `configs/model_config.json`
- `configs/model_quality_report.json`
- `configs/cross_validation_baseline.csv`
- `configs/feature_importance.csv`
- `logs/training_log.csv`

## Cara Menjalankan FastAPI

Dari root project:

```bash
uvicorn app.app:app --reload
```

API tersedia di:

```text
http://127.0.0.1:8000
```

Dokumentasi interaktif:

```text
http://127.0.0.1:8000/docs
```

## Endpoint API

`POST /predict`

Contoh request:

```json
{
  "gender": "male",
  "age_months": 24,
  "weight_kg": 8.0,
  "height_cm": 74.0
}
```

Contoh yang sama tersedia di:

```text
samples/sample_request.json
```

Nilai `gender` yang valid:

- `male`
- `female`
- `laki-laki`
- `perempuan`

Contoh response:

```json
{
  "prediction_label": "Stunting",
  "probability": 0.9525,
  "threshold": 0.5,
  "input_data": {
    "gender": "male",
    "gender_encoded": 1,
    "age_months": 24,
    "weight_kg": 8.0,
    "height_cm": 74.0,
    "feature_order": [
      "Gender_Enc",
      "Age_Month",
      "Weight",
      "Height",
      "BMI"
    ]
  },
  "calculated_bmi": 14.61
}
```

## Production Readiness

API melakukan:

- load model dari `models/stunting_model.keras`
- load scaler dari `models/scaler.pkl`
- load threshold dan metadata dari `configs/model_config.json`
- validasi `age_months` 0-60 bulan
- validasi `weight_kg` 1-30 kg
- validasi `height_cm` 30-130 cm
- validasi `gender` hanya menerima nilai yang didukung
- kalkulasi BMI otomatis
- transform fitur sesuai urutan training
- prediksi memakai threshold hasil tuning, bukan hard-code tersembunyi
- return JSON response yang ringkas dan mudah dikonsumsi frontend/client

## Catatan Penggunaan

Model ini ditujukan sebagai alat skrining awal dan edukasi berbasis data antropometri sederhana. Hasil prediksi tidak menggantikan diagnosis tenaga kesehatan, pemeriksaan klinis, atau penilaian antropometri resmi.
